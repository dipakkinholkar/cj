package com.main.home;

import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dipak.service.controller.addNewProductDAO;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Home {

	public JFrame addProduct;
	private JTextField productName;
	private JTextField productQuantity;
	private JTextField companyName;
	private JTextField companyContact;
	private JTextField productRate;
	private JTextField checkinDate;
	private JTextField productID;
	
	
	// variable for sending data
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.addProduct.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		addProduct = new JFrame();
		addProduct.getContentPane().setBackground(Color.PINK);
		addProduct.getContentPane().setLayout(null);
		
		JLabel lblAddNewProduct = new JLabel("Add New Product");
		lblAddNewProduct.setBounds(138, 13, 487, 86);
		lblAddNewProduct.setForeground(Color.BLUE);
		lblAddNewProduct.setFont(new Font("Tahoma", Font.BOLD, 34));
		lblAddNewProduct.setBackground(Color.PINK);
		addProduct.getContentPane().add(lblAddNewProduct);
		
		JLabel lblProductName = new JLabel("Product ID");
		lblProductName.setBounds(138, 109, 104, 32);
		lblProductName.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblProductName.setForeground(Color.WHITE);
		addProduct.getContentPane().add(lblProductName);
		
		JLabel lblCompanyName = new JLabel("Company Name");
		lblCompanyName.setBounds(118, 231, 154, 32);
		lblCompanyName.setForeground(Color.WHITE);
		lblCompanyName.setFont(new Font("Tahoma", Font.BOLD, 18));
		addProduct.getContentPane().add(lblCompanyName);
		
		JLabel lblCompanyContact = new JLabel("Company Contact");
		lblCompanyContact.setBounds(118, 297, 181, 32);
		lblCompanyContact.setForeground(Color.WHITE);
		lblCompanyContact.setFont(new Font("Tahoma", Font.BOLD, 18));
		addProduct.getContentPane().add(lblCompanyContact);
		
		JLabel lblProductQuantity = new JLabel("Product Quantity");
		lblProductQuantity.setBounds(118, 367, 154, 32);
		lblProductQuantity.setForeground(Color.WHITE);
		lblProductQuantity.setFont(new Font("Tahoma", Font.BOLD, 18));
		addProduct.getContentPane().add(lblProductQuantity);
		
		JLabel lblProductRate = new JLabel("Product Rate");
		lblProductRate.setBounds(134, 439, 154, 32);
		lblProductRate.setForeground(Color.WHITE);
		lblProductRate.setFont(new Font("Tahoma", Font.BOLD, 18));
		addProduct.getContentPane().add(lblProductRate);
		
		JLabel lblCheckinDate = new JLabel("CheckIn Date");
		lblCheckinDate.setBounds(133, 505, 154, 32);
		lblCheckinDate.setForeground(Color.WHITE);
		lblCheckinDate.setFont(new Font("Tahoma", Font.BOLD, 18));
		addProduct.getContentPane().add(lblCheckinDate);
		
		
		//input values from textfields.
		
		productName = new JTextField();
		productName.setForeground(new Color(128, 128, 128));
		productName.setFont(new Font("Tahoma", Font.BOLD, 18));
		productName.setBounds(295, 167, 405, 38);
		addProduct.getContentPane().add(productName);
		productName.setColumns(10);
		
		productQuantity = new JTextField();
		productQuantity.setFont(new Font("Tahoma", Font.BOLD, 18));
		productQuantity.setBounds(298, 366, 212, 38);
		productQuantity.setColumns(10);
		addProduct.getContentPane().add(productQuantity);
		
		companyName = new JTextField();
		companyName.setForeground(Color.GRAY);
		companyName.setFont(new Font("Tahoma", Font.BOLD, 18));
		companyName.setColumns(10);
		companyName.setBounds(295, 228, 405, 38);
		addProduct.getContentPane().add(companyName);
		
		companyContact = new JTextField();
		companyContact.setForeground(Color.GRAY);
		companyContact.setFont(new Font("Tahoma", Font.BOLD, 18));
		companyContact.setColumns(10);
		companyContact.setBounds(295, 291, 405, 38);
		addProduct.getContentPane().add(companyContact);
		
		productRate = new JTextField();
		productRate.setFont(new Font("Tahoma", Font.BOLD, 18));
		productRate.setColumns(10);
		productRate.setBounds(298, 433, 212, 38);
		addProduct.getContentPane().add(productRate);
		
		checkinDate = new JTextField();
		checkinDate.setFont(new Font("Tahoma", Font.BOLD, 18));
		checkinDate.setColumns(10);
		checkinDate.setBounds(299, 499, 212, 38);
		addProduct.getContentPane().add(checkinDate);
		addProduct.setBounds(100, 100, 1028, 713);
		addProduct.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


		JButton btnAddProdcut = new JButton("Add Product");
		
		btnAddProdcut.setBackground(new Color(250, 250, 210));
		btnAddProdcut.setForeground(new Color(0, 0, 0));
		btnAddProdcut.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnAddProdcut.setBounds(608, 554, 119, 38);
		addProduct.getContentPane().add(btnAddProdcut);
		
		JLabel lblProductName_1 = new JLabel("Product Name");
		lblProductName_1.setForeground(Color.WHITE);
		lblProductName_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblProductName_1.setBounds(118, 168, 154, 32);
		addProduct.getContentPane().add(lblProductName_1);
		
		productID = new JTextField();
		productID.setFont(new Font("Tahoma", Font.BOLD, 18));
		productID.setColumns(10);
		productID.setBounds(298, 106, 119, 38);
		addProduct.getContentPane().add(productID);
		
		btnAddProdcut.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				
				String proID=productID.getText();
				String proName=productName.getText();
				String comName=companyName.getText();
				String comContact=companyContact.getText();
				String proQuantity=productQuantity.getText();
				String proRate=productRate.getText();
				String checkInDate=checkinDate.getText();
				
				
			addNewProductDAO add=new addNewProductDAO(proID,proName,comName,comContact,proQuantity,proRate,checkInDate);
			
			try {
				boolean result=	add.addProduct();
				
				if(result==true)
				{
					JOptionPane.showMessageDialog(addProduct, "Product Added Successfully!.");
					
				}
				else
				{

					JOptionPane.showMessageDialog(addProduct, "Failed to Add Product!.");
				
				}
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			}
		});
		
		
		
		
		
	}
}
