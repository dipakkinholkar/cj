package dipak.service.login;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.Color;
import javax.swing.JTextField;

import com.connection.DAO.DAO;
import com.main.home.Home;

import dipak.service.controller.LoginDAO;

import javax.swing.JPasswordField;
import javax.swing.JButton;

public class adminLogin {

	private JFrame frame;
	private JTextField username;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			
			public void run() {
				try {
					adminLogin window = new adminLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public adminLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 240, 245));
		frame.setBounds(100, 100, 729, 518);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setForeground(Color.PINK);
		lblNewLabel.setBackground(Color.PINK);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 36));
		lblNewLabel.setBounds(291, 38, 102, 63);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setForeground(Color.DARK_GRAY);
		lblUsername.setFont(new Font("Times New Roman", Font.BOLD, 17));
		lblUsername.setBackground(Color.BLACK);
		lblUsername.setBounds(168, 145, 74, 63);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(Color.DARK_GRAY);
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 17));
		lblPassword.setBackground(Color.BLACK);
		lblPassword.setBounds(167, 212, 87, 63);
		frame.getContentPane().add(lblPassword);
		
		username = new JTextField();
		username.setFont(new Font("Tahoma", Font.BOLD, 15));
		username.setBounds(259, 160, 249, 34);
		frame.getContentPane().add(username);
		username.setColumns(10);
		
		password = new JPasswordField();
		password.setFont(new Font("Tahoma", Font.BOLD, 15));
		password.setBounds(259, 227, 249, 34);
		frame.getContentPane().add(password);
		
		JButton login = new JButton("Login");
		login.setBackground(new Color(240, 255, 255));
		login.setForeground(new Color(0, 128, 0));
		login.setFont(new Font("Times New Roman", Font.BOLD, 15));
		login.setBounds(448, 296, 74, 34);
		frame.getContentPane().add(login);
	
		
		
		login.addActionListener(new ActionListener()
				{

					@Override
					public void actionPerformed(ActionEvent arg0) {
					
						
						 String admin= username.getText();
						char[] pass=password.getPassword();
						String password = String. valueOf(pass);
					
						try {
							
							boolean check=LoginDAO.checkAdmin(admin, password);
						
							if(check==true)
							{
								
								frame.dispose();
								
							Home h=new Home();
							h.addProduct.setVisible(true);
							}
							else
							{
								JOptionPane.showMessageDialog(login, "Login Failed!");
							}
							
							
						} catch (ClassNotFoundException | SQLException e) {
							
							e.printStackTrace();
						}
						
						
					}
						
				});
	
	}
}
