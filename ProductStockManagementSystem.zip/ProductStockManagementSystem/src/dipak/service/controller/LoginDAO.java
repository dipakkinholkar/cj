package dipak.service.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.connection.DAO.DAO;

public class LoginDAO {
	
	
	public static boolean checkAdmin(String username , String password) throws ClassNotFoundException, SQLException
	{
		Connection con=DAO.getConnection();
		
		PreparedStatement ps=null;
		ps=con.prepareStatement("select username , password from login where username=? and password=?");
		
		ps.setString(1, username);
		ps.setString(2, password);
		

		ResultSet rs=ps.executeQuery();
		
		boolean status=rs.next();
		
		
		if(status==true)
		{
			return true;
		}
		ps.close();
	return false;	
	}
	

}
