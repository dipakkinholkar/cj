package dipak.service.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.connection.DAO.DAO;

public class addNewProductDAO {
	
	private Long proID;
	private String proName;
	private String comName;
	private Long comContact;
	private Long proQuantity;
	private String checkInDate;
	private Long proRate;

	public addNewProductDAO(String proID,String proName ,String comName ,String comContact ,String proQuantity ,String proRate,String checkInDate)
	{
		this.proID=Long.parseLong(proID);
		this.proName=proName;
		this.comName=comName;
		this.comContact=Long.parseLong(comContact);
		this.proQuantity=Long.parseLong(proQuantity);
		this.proRate=Long.parseLong(proRate);
		this.checkInDate=checkInDate;
	}
	
	public boolean addProduct() throws  ClassNotFoundException, SQLException
	{
		String query="insert into productlist values(?,?,?,?,?,?,?)";
		Connection con=DAO.getConnection();
		
		try {
		PreparedStatement ps=con.prepareStatement(query);
		
		ps.setLong(1, proID);
		ps.setString(2,proName);
		ps.setString(3,comName);
		ps.setLong(4,comContact);
		ps.setLong(5,proQuantity);
		ps.setLong(6,proRate);
		ps.setString(7,checkInDate);
		
		ResultSet rs=ps.executeQuery();
		
		
		if(rs!=null)
		{
			return true;
		}
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
		return false;
	
		
		
		}
	
	
	


}
